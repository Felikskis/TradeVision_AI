Комплект для сборки TradeVision AI APK с телефона через GitHub Actions.

Содержимое:
- TradeVisionAI_Full_Source.zip — исходный Android-проект.
- .github/workflows/build-apk.yml — автоматическая сборка APK.
- ИНСТРУКЦИЯ_С_ТЕЛЕФОНА.md — подробные шаги.

Сначала прочитай ИНСТРУКЦИЯ_С_ТЕЛЕФОНА.md.
APK в этом архиве пока нет: он будет создан GitHub Actions после запуска сборки.
